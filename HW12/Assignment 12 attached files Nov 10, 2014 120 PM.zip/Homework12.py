from graphics import *
from random import *
from time import sleep

class Button:
    """A button is a labeled rectangle in a window.
    It is activated or deactivated with the activate()
    and deactivate() methods. The clicked(p) method
    returns true if the button is active and p is inside it."""

    def __init__(self, win, center, width, height, label, color):
        """ Creates a rectangular button, eg:
        qb = Button(myWin, centerPoint, width, height, 'Quit','yellow') """ 
        self.xmax, self.xmin = center.getX()+width/2.0, center.getX()-width/2.0
        self.ymax, self.ymin = center.getY()+height/2.0, center.getY()-height/2.0
        p1,p2 = Point(self.xmin, self.ymin), Point(self.xmax, self.ymax)
        self.rect = Rectangle(p1,p2)
        self.rect.setFill(color)
        self.label = Text(center, label)
        self.win = win
        self.active = False

    def clicked(self, p):
        "Returns true if button active and p is inside"
        return (self.active and
                self.xmin <= p.getX() <= self.xmax and
                self.ymin <= p.getY() <= self.ymax)

    def activate(self):
        "Sets this button to 'active'and draws the button."
        if self.active == False:
            self.active = True
            self.rect.draw(self.win)
            self.label.draw(self.win)

    def deactivate(self):
        "Sets this button to 'inactive' and undraws the button."
        if self.active == True:
            self.active = False
            self.rect.undraw()
            self.label.undraw()
            
class Words:
    '''reads a file of words and creates a list of words'''
    def __init__(self,filename):
        
    def get_word(self):
        '''returns a random word from the list'''

class Guess:
    def __init__ (self,word):
        
    def missed (self):
        '''returns the word string that could not be guessed'''
        
    def guess_letter (self,letter):
        '''uncovers letters that match the guess, counts the bad guesses
        and keeps track of the letters guessed. It returns a number, 0,
        if the letter has already been guessed, 1 if the letter is NOT
        in the word and 2 if the letter IS in the word'''
        
    def gameover (self):
        '''returns Boolean, T if word is guessed or the number of guesses
        has exceeded the limit and F otherwise'''
        
    def num_of_guesses(self):
        '''returns a STRING with the number of remaining guesses'''
        
    def letters_guessed (self):
        '''returns a string, in alphabetical order, of all the letters
        that have been guessed'''
        
    def   __str__ (self):
        '''returns a string with the letters in the word and _ for each
        unguessed letter separated by spaces'''
        
class Noose:
    def __init__(self,win):
        '''creates a Noose object with 7 sections that can be drawn one at a
        time in the win canvas'''
    def wrong(self, sect_num):
        '''draws another of the 7 sections to the noose platform and/or figure'''

def main():

def play_one_game():

main()
